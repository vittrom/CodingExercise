package antgame;

public class Point {
    private int row;
    private int col;

    public Point(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public int getRow() {
        return this.row;
    }

    public int getCol() {
        return this.col;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public void update(int row, int col) {
        setRow(row);
        setCol(col);
    }

    @Override
    public boolean equals(Object o) {

        if (o == this) {
            return true;
        }

        if (!(o instanceof Point)) {
            return false;
        }

        Point c = (Point) o;

        return Integer.compare(this.row, c.getRow()) == 0
                && Integer.compare(this.col, c.getCol()) == 0;
    }
}
