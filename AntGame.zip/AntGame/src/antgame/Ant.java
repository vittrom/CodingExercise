package antgame;

import java.util.Random;

public class Ant {
    private Point currentLoc;
    private Point lastLoc;

    public Ant(int row, int col) {
        this.currentLoc = new Point(row, col);
        this.lastLoc = new Point(row, col);
    }

    public Point makeMove() {
        Random rand = new Random();

        // Stay same row/col, move up by one, move down by one
        int row = rand.nextInt(3) - 1;
        int col = rand.nextInt(3) - 1;

        return new Point(this.currentLoc.getRow() + row, this.currentLoc.getCol() + col);
    }

    public void moveTo(Point p) {
        this.lastLoc = new Point(this.currentLoc.getRow(), this.currentLoc.getCol());
        this.currentLoc.update(p.getRow(), p.getCol());
    }

    public Point getCurrentLoc() {
        return this.currentLoc;
    }

    public Point getLastLoc() {
        return this.lastLoc;
    }

    public boolean compareCurrent(Ant other) {
        return this.currentLoc.equals(other.getCurrentLoc());
    }

    public boolean compareLast(Ant other) {
        return this.currentLoc.equals(other.getLastLoc()) && this.lastLoc.equals(other.getCurrentLoc());
    }
}

