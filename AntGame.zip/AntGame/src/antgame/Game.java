package antgame;

public class Game {
    public final int NROWS;
    public final int NCOLS;
    public boolean diagMove;
    public boolean backMove;

    public Game(int nrows, int ncols) {
        NROWS = nrows;
        NCOLS = ncols;
    }

    public boolean validMove(Ant ant, Point newPoint) {
        if (newPoint.equals(ant.getCurrentLoc())) {
            return false;
        }

        if (!inRange(newPoint.getCol(), NCOLS) || !inRange(newPoint.getRow(), NROWS)) {
            return false;
        }

        if (!this.backMove && newPoint.equals(ant.getLastLoc())) {
            return false;
        }

        Point currentLoc = ant.getCurrentLoc();
        int diffCols = Math.abs(currentLoc.getCol() - newPoint.getCol());
        int diffRows = Math.abs(currentLoc.getRow() - newPoint.getRow());

        if (!this.diagMove && (diffCols + diffRows == 2)) {
            return false;
        }

        return true;
    }

    private boolean inRange(int dim, int maxVal) {
        return dim >= 0 && dim < maxVal;
    }
}
