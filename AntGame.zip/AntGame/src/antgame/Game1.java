package antgame;

public class Game1 extends Game {

    public Game1(int nrows, int ncols) {
        super(nrows, ncols);
        super.backMove = true;
        super.diagMove = false;
    }

    @Override
    public String toString() {
        return "Playing game 1 on board with rows: " + NROWS + " and cols: " + NCOLS
                + ". \n Rules: NO diagonal moves, YES backward moves";
    }

}

