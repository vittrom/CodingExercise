package antgame;

public class Game2 extends Game {

    public Game2(int nrows, int ncols) {
        super(nrows, ncols);
        super.backMove = true;
        super.diagMove = true;
    }

    @Override
    public String toString() {
        return "Playing game 2 on board with rows: " + NROWS + " and cols: " + NCOLS
                + ". \n Rules: YES diagonal moves, YES backward moves";
    }

}
