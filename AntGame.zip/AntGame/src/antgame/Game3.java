package antgame;

public class Game3 extends Game {

    public Game3(int nrows, int ncols) {
        super(nrows, ncols);
        super.backMove = false;
        super.diagMove = true;
    }

    @Override
    public String toString() {
        return "Playing game 3 on board with rows: " + NROWS + " and cols: " + NCOLS
                + ". \n Rules: YES diagonal moves, NO backward moves";
    }

}
