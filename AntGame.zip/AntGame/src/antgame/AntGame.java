package antgame;

public class AntGame {
    public static final int moveTime = 10;
    public static final int NROWS = 8;
    public static final int NCOLS = 8;
    public static final int REPETITIONS = 100000;

    public static void main(String[] args) {
        Game1 game1 = new Game1(NROWS, NCOLS);
        Game2 game2 = new Game2(NROWS, NCOLS);
        Game3 game3 = new Game3(NROWS, NCOLS);

        AntGame.simulate(game1, REPETITIONS);
        AntGame.simulate(game2, REPETITIONS);
        AntGame.simulate(game3, REPETITIONS);
    }

    public static void simulate(Game game, int repetitions) {
        System.out.println(game.toString());

        int sameLocMoves = 0;
        int nTimesSameLoc = 0;
        int switchLocMoves = 0;
        int nTimesSwitchLoc = 0;

        for (int i = 0; i < repetitions; i++) {
            Ant a = new Ant(0, 0);
            Ant b = new Ant(game.NROWS - 1, game.NCOLS - 1);
            boolean sameLoc = false;
            boolean switchLoc = false;
            int moves = 0;

            while (!sameLoc && !switchLoc) {

                Point aMove = a.makeMove();
                while (!game.validMove(a, aMove)) {
                    aMove = a.makeMove();
                }
                a.moveTo(aMove);

                Point bMove = b.makeMove();
                while (!game.validMove(b, bMove)) {
                    bMove = b.makeMove();
                }
                b.moveTo(bMove);

                moves++;

                if (!sameLoc) {
                    sameLoc = a.compareCurrent(b);
                    if (sameLoc) {
                        sameLocMoves += moves;
                        nTimesSameLoc += 1;
                    }
                }

                if (!switchLoc) {
                    switchLoc = a.compareLast(b);
                    if (switchLoc) {
                        switchLocMoves += moves;
                        nTimesSwitchLoc += 1;
                    }
                }

            }
        }

        if (nTimesSameLoc == 0) {
            System.out.println(
                    "Same location average time: Infinite. No occurrences over " + repetitions + " simulations.");
        } else {
            System.out.println("Same location average time: " + Math.round(sameLocMoves * moveTime / nTimesSameLoc));
        }

        if (nTimesSwitchLoc == 0) {
            System.out.println(
                    "Switch location average time: Infinite. No occurrences over " + repetitions + " simulations.");
        } else {
            System.out.println(
                    "Switch location average time: " + Math.round(switchLocMoves * moveTime / nTimesSwitchLoc));
        }
    }
}
