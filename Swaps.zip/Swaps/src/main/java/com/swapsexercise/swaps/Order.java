package com.swapsexercise.swaps;


public class Order {
    private Direction direction;
    private double price;
    private int amount;

    public Order(Direction direction, double price, int amount) {
        this.direction = direction;
        this.price = price;
        this.amount = amount;
    }

    public Direction getDirection() {
        return direction;
    }

    public double getPrice() {
        return price;
    }

    public int getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "Added order: direction " + this.direction + ", amount " + this.amount + ", price " + this.price;
    }
}

