package com.swapsexercise.swaps;

import java.util.ArrayList;
import java.util.Random;

public class RandomOrderBook {

    public static final int MIN_AMOUNT = 1;
    public static final int MAX_AMOUNT = 5;
    public static final double MID_PRICE = 100.0;
    public static final double LOW_PRICE = 90.0;
    public static final double HIGH_PRICE = 110.0;

    public static OrderBook generateOrderBook(int nOrders) {
        OrderBook orderBook = new OrderBook(new ArrayList<>());
        for (int i = 0; i < nOrders; i++) {

            // Generate order and add to orderbook
            Order o = generateOrder();
            orderBook.addOrder(o);
        }
        return orderBook;
    }

    public static int generateRandomAmount(int minAmount, int maxAmount) {
        Random rand = new Random();
        return rand.nextInt((maxAmount - minAmount) + 1) + minAmount;
    }

    public static double generateRandomPrice(double minPrice, double maxPrice) {
        Random rand = new Random();
        return minPrice + (maxPrice - minPrice) * rand.nextDouble();
    }

    public static Order generateOrder() {
        Random rand = new Random();
        Direction direction;
        double r = rand.nextDouble();

        // Generate random direction
        if (r < 0.5) {
            direction = Direction.BUY;
        } else {
            direction = Direction.SELL;
        }

        // Generate order amount and price
        int amount = generateRandomAmount(MIN_AMOUNT, MAX_AMOUNT);
        double price;

        if (direction.equals(Direction.BUY)) {
            price = generateRandomPrice(LOW_PRICE, MID_PRICE);
        } else {
            price = generateRandomPrice(MID_PRICE, HIGH_PRICE);
        }

        return new Order(direction, price, amount);
    }

}

