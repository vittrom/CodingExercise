package com.swapsexercise.swaps;

import java.util.concurrent.Exchanger;
import java.util.Random;
import java.util.Optional;

public class Requests implements Runnable {
    private Exchanger<OrderBook> ex;
    private OrderBook ob;
    private static final int MIN_AMOUNT = 1;
    private static final int MAX_AMOUNT = 100;
    private static final int MIN_TIME = 100;
    private static final int MAX_TIME = 1000;

    public Requests(Exchanger<OrderBook> exchanger) {
        this.ex = exchanger;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Random rand = new Random();
                Direction direction;
                this.ob = ex.exchange(this.ob);
                RFQ rfq = new RFQ(this.ob);

                if (rand.nextDouble() < 0.5) {
                    direction = Direction.BUY;
                } else {
                    direction = Direction.SELL;
                }
                int amount = RandomOrderBook.generateRandomAmount(MIN_AMOUNT, MAX_AMOUNT);

                Optional<Double> quote = rfq.getQuote(direction, amount);
                ApplicationLogger.log("Getting quote for direction: " + direction + " and amount: " + amount);

                if (!quote.isPresent()) {
                    ApplicationLogger.log("Empty quote for direction: " + direction + " and amount: " + amount);
                } else {

                    ApplicationLogger.log(
                            "Quote for direction: " + direction + " and amount: " + amount + " is: " + quote.get());
                }

                Thread.sleep(generateRandomInt(MIN_TIME, MAX_TIME)); // Random interval for requests

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    private static int generateRandomInt(int minAmount, int maxAmount) {
        Random rand = new Random();
        return rand.nextInt((maxAmount - minAmount) + 1) + minAmount;
    }
}

