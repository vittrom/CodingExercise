package com.swapsexercise.swaps;


import java.util.concurrent.Exchanger;

public class Swaps {

    public static void main(String[] args) {
        ApplicationLogger.setLogging("file.log");

        Exchanger<OrderBook> exchanger = new Exchanger<>();
        SimulateOrderBook ob = new SimulateOrderBook(exchanger);
        Requests rfqs = new Requests(exchanger);

        (new Thread(ob)).start();
        (new Thread(rfqs)).start();
    }
}
