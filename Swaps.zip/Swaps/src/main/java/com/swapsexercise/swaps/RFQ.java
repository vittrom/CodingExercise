package com.swapsexercise.swaps;

import java.util.*;
import java.util.stream.*;

public class RFQ {
    public static final double SPREAD = 0.01;
    private OrderBook currentOrderbook;

    public RFQ(OrderBook orderBook) {
        this.currentOrderbook = orderBook;
    }

    public Optional<Double> getQuote(Direction direction, int amount) {
        ArrayList<Order> orders = this.currentOrderbook.getOrders();

        Optional<Double> midPrice = getMidPrice(orders, direction, amount);
        if (!midPrice.isPresent()) {
            return Optional.empty();
        }
        if (direction == Direction.BUY) {
            return Optional.of(midPrice.get() + SPREAD);
        } else {
            return Optional.of(midPrice.get() - SPREAD);
        }
    }

    private Optional<Double> getMidPrice(List<Order> orders, Direction direction, int amount) {

        // Sort opposite direction orders by price
        List<Order> sortedOrders = orders.stream().filter(o -> o.getDirection() != direction) // only keep opposite
                                                                                              // direction
                .sorted(Comparator.comparing(Order::getPrice)) // sort by price smallest to largest
                .collect(Collectors.toList());

        if (direction == Direction.SELL) {
            Collections.reverse(sortedOrders);
        }

        // Get size-weighted avg price for quote
        int currentAmount = 0;
        double currentPrice = 0.0;
        for (Order order : sortedOrders) {
            int orderAmount = Math.min(order.getAmount(), amount - currentAmount);
            currentAmount += orderAmount;
            currentPrice += (orderAmount * order.getPrice());
            if (orderAmount == amount) {
                break;
            }
        }

        if (currentAmount < amount) {
            return Optional.empty();
        } else {
            return Optional.of(currentPrice / currentAmount);
        }
    }
}
