package com.swapsexercise.swaps;

public enum Direction {
    BUY,
    SELL
}

