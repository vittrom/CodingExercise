package com.swapsexercise.swaps;

import java.util.concurrent.Exchanger;
import java.util.Random;

public class SimulateOrderBook implements Runnable {

    private static final int MIN_TIME = 100;
    private static final int MAX_TIME = 1000;

    private Exchanger<OrderBook> ex;
    public OrderBook ob;

    public SimulateOrderBook(Exchanger<OrderBook> exchanger) {
        this.ex = exchanger;
        this.ob = RandomOrderBook.generateOrderBook(20);
    }

    @Override
    public void run() {
        while (true) {
            try {
                Order o = RandomOrderBook.generateOrder();
                ApplicationLogger.log("Generated order: " + o.toString());

                this.ob.addOrder(o);
                ApplicationLogger.log("Order added to order book");

                ex.exchange(this.ob);

                Thread.sleep(generateRandomInt(MIN_TIME, MAX_TIME)); // Random time at which orders arrive in the
                                                                     // orderbook
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static int generateRandomInt(int minAmount, int maxAmount) {
        Random rand = new Random();
        return rand.nextInt((maxAmount - minAmount) + 1) + minAmount;
    }
}

