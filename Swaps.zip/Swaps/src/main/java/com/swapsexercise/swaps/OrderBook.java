package com.swapsexercise.swaps;

import java.util.ArrayList;

public class OrderBook {
    private ArrayList<Order> orders;

    public OrderBook(ArrayList<Order> orders) {
        this.orders = orders;
    }

    public ArrayList<Order> getOrders() {
        return this.orders;
    }

    public void addOrder(Order o) {
        this.orders.add(o);
    }
}
