package com.swapsexercise.swaps;

import java.io.IOException;
import java.util.logging.Formatter;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.logging.ConsoleHandler;

public class ApplicationLogger {
    private static final Logger LOGGER = Logger.getLogger(ApplicationLogger.class.getName());

    public static void setLogging(String path) {
        Handler fileHandler = null;
        Handler consoleHandler = null;

        Formatter simpleFormatter = null;
        try {

            // Creating FileHandler and ConsoleHandler
            fileHandler = new FileHandler(path);
            consoleHandler = new ConsoleHandler();

            // Creating SimpleFormatter
            simpleFormatter = new SimpleFormatter();

            // Assigning handler to logger
            LOGGER.addHandler(fileHandler);
            LOGGER.addHandler(consoleHandler);

            // Setting formatter to the handler
            fileHandler.setFormatter(simpleFormatter);
            consoleHandler.setFormatter(simpleFormatter);

            // Setting Level to ALL
            fileHandler.setLevel(Level.ALL);
            consoleHandler.setLevel(Level.ALL);
            LOGGER.setLevel(Level.ALL);
        } catch (IOException exception) {
            LOGGER.log(Level.SEVERE, "Error occur in FileHandler.", exception);
        }
    }

    public static void log(String msg) {
        LOGGER.log(Level.ALL, msg);
    }
}

